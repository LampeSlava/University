import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Address[] addresses = new Address[10];
        addresses[0] = new Address("New York", "5th Ave.", "1", "1B");
        addresses[1] = new Address("New York", "Broadway", "10", "100");
        addresses[2] = new Address("Washington D.C.", "Main st.", "5", "15");
        addresses[3] = new Address("New Vasyuki", "Whiskey st.", "1", "1");
        addresses[4] = new Address("Hogwarts", "Castle blvd.", "X", "XXX");

        Address addressStudent = new Address("Minsk", "Kalvarijskaya", "21A", "3B");
        Address addressTeacher = new Address("Minsk", "Brovk", "1", "149");

        Person[] students = new Person[10];
        students[0] = new Person("John", "Doe", 1970, addresses[0], "Student");
        students[1] = new Person("Donald", "Trump", 1940, addresses[1], "Student");
        students[2] = new Person("Blin", "Clinton", 1945, addresses[2], "Student");
        students[3] = new Person("Henry", "Ford", 1900, addresses[3], "Student");
        students[4] = new Person("Harry", "Potter", 1980, addresses[4], "Student");

        //interface loop
        boolean exitProgram = false;
        String opLetter;
        char opChar;
        Scanner input = new Scanner(System.in);

        while (!exitProgram) {
            showMenu();
            listStudents(students);

            System.out.print("Enter operation code (letter in brackets): ");
            opLetter = input.nextLine(); opChar = Character.toLowerCase(opLetter.charAt(0));

            switch (opChar) {
                case 'e':
                    exitProgram = true;
                    break;
                case 'l':
                    break;
                case 'n':
                    System.out.println("New student! Not implemented yet!");
                    break;
                case 'u':
                    System.out.println("Update student! Not implemented yet!");
                    break;
                case 'd':
                    students = deleteStudent(students);
                    break;
                default:
                    System.out.println("Enter correct letter!");
            }

        }
        input.close();

        /*Person testguy = new Person("Vasya", "Pupkin", 1985, addressStudent, "Student");
        System.out.println("Info about student: " + testguy);

        Teacher teacher1 = new Teacher("Vova", "Putler", 1955, addressTeacher, "Teacher", 1, 10);
        System.out.println("Info about teacher: " + teacher1);

        System.out.println("Info about teacher's wage: " + teacher1.getTariff() * teacher1.getHours());

        teacher1.setTariff(12.5);

        System.out.println("Now hourly tariff is " + teacher1.getTariff());
        System.out.println("Now teacher's wage: " + teacher1.getTariff() * teacher1.getHours());

        StudyGroup newGroup = new StudyGroup("New group", 2, teacher1, testguy);
        System.out.println("Info about group: " + newGroup);

        addressStudent.setApartment("126");
        addressTeacher.setApartment("99");

        System.out.println("Info about persons after address change");
        System.out.println("Info about student: " + testguy);
        System.out.println("Info about teacher: " + teacher1);
*/

    }

     static void showMenu() {
        System.out.println("+------------------------------------------------------------------------------------------+");
        System.out.println("|  (L)ist students  |  (N)ew student  |  (U)pdate student  |  (D)elete student  |  (E)xit  |");
        System.out.println("+------------------------------------------------------------------------------------------+");
    }

     static void listStudents(Person[] students) {
        for (int i = 0; i < students.length - 1; i++) {
            //if (students[i] != null) {
                System.out.println("Student " + i + ": " + students[i]);
            //}
        }
        System.out.println("+------------------------------------------------------------------------------------------+");
    }

     static Person[] deleteStudent (Person[] students) {

        int studentToDelete;

        //input block
        System.out.print("Enter number of student to delete: ");
        Scanner input = new Scanner(System.in);
        studentToDelete = input.nextInt();

        if ((studentToDelete < 0) || (studentToDelete > students.length - 1)) {
            System.out.println("ERROR! Wrong student number!");
            return students;
        }

        //input - OK
        Person[] tempStudents = new Person[students.length - 1];

        int j = 0; //counter for new array

        for (int i = 0; i < students.length; i++) {
            if (i != studentToDelete) {
                tempStudents[j] = students[i];
                j++;
            }
        }
        return tempStudents;
    }
}
