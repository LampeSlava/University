import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {

        ArrayList<Address> addresses = new ArrayList<>(10);
        ArrayList<Person> people = new ArrayList<>(10);
        loadStudents(people, addresses);

        //interface loop
        boolean exitProgram = false;
        String opLetter;
        char opChar;
        Scanner input = new Scanner(System.in);

        while (!exitProgram) {
            showMenu();
            listStudents(people);

            System.out.print("Enter operation code (letter in brackets): ");
            opLetter = input.nextLine();
            opChar = Character.toLowerCase(opLetter.charAt(0));

            switch (opChar) {
                case 'e':
                    exitProgram = true;
                    break;
                case 'l':
                    break;
                case 'n':
                    addStudent(addresses, people);
                    break;
                case 'u':
                    System.out.println("Update student! Not implemented yet!");
                    break;
                case 'd':
                    deleteStudent(people);
                    break;
                case 's':
                    saveStudents(people, addresses);
                    break;
                default:
                    System.out.println("Enter correct letter!");
            }
        }
        input.close();
    }

    private static void loadStudents(ArrayList<Person> people, ArrayList<Address> addresses) throws IOException {

        FileReader myfile_p = null;
        FileReader myfile_a = null;
        try {
            //files init
            String filepath_a = Paths.get("").toAbsolutePath().toString();
            myfile_a = new FileReader(filepath_a + "\\src\\addresses.txt");
            BufferedReader reader_a = new BufferedReader(myfile_a);

            String filepath_p = Paths.get("").toAbsolutePath().toString();
            myfile_p = new FileReader(filepath_p + "\\src\\persons.txt");
            BufferedReader reader_p = new BufferedReader(myfile_p);

            String textLine;

            //data reading
            while ((textLine = reader_a.readLine()) != null) {
                //addresses
                String[] dataFields_a = textLine.split("\t"); //array of text line elements
                addresses.add(new Address(dataFields_a[0], dataFields_a[1], dataFields_a[2], dataFields_a[3]));

                //people
                textLine = reader_p.readLine();
                String[] dataFields_p = textLine.split("\t"); //array of text line elements
                people.add(new Person(dataFields_p[1], dataFields_p[0], Integer.valueOf(dataFields_p[2]), addresses.get(addresses.size() - 1), dataFields_p[3]));
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
            System.exit(2);
        } catch (IOException e) {
            System.out.println("Error reading file");
            System.out.println(e.getMessage());
            System.exit(3);
        } finally {
            if (myfile_p != null) {
                myfile_p.close();
            }
        }
    }

    private static void saveStudents(ArrayList<Person> people, ArrayList<Address> addresses) {

        FileWriter myfile = null;
        try {
            String filepath = Paths.get("").toAbsolutePath().toString();
            myfile = new FileWriter(filepath + "\\src\\persons.txt");
            BufferedWriter writer = new BufferedWriter(myfile);

            for (Person student : people) {
                String dataLine = String.join("\t", student.getName(), student.getSurname(), Integer.toString(student.getYear()), student.getPstatus()) + "\n";
                try {
                    writer.write(dataLine);
                } catch (IOException e) {
                    System.out.println("Error writing to file 'persons.txt'!");
                    e.getCause();
                }
            }
            writer.flush();
            writer.close();
            System.out.println("Data file 'persons.txt' saved!");
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        FileWriter myfile_w = null;
        try {
            String filepath = Paths.get("").toAbsolutePath().toString();
            myfile_w = new FileWriter(filepath + "\\src\\addresses.txt");
            BufferedWriter writer = new BufferedWriter(myfile_w);

            for (Address address : addresses) {
                String dataLine = String.join("\t", address.getCity(), address.getStreet(), address.getBuilding(), address.getApartment()) + "\n";
                try {
                    writer.write(dataLine);
                } catch (IOException e) {
                    System.out.println("Error writing to file 'addresses.txt'!");
                    e.getCause();
                }
            }
            writer.flush();
            writer.close();
            System.out.println("Data file 'addresses.txt' saved!");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    static void showMenu() {
        System.out.println(" ");
        System.out.println("+----------------------------------------------------------------------------------------------+");
        System.out.println("| (L)ist students | (N)ew student | (U)pdate student | (D)elete student | (S)ave data | (E)xit |");
        System.out.println("+----------------------------------------------------------------------------------------------+");
    }

    static void listStudents(ArrayList<Person> students) {
        for (int i = 0; i < students.size(); i++) {
            System.out.println("Student " + i + ": " + students.get(i));
        }
        System.out.println("+----------------------------------------------------------------------------------------------+");
        //!?!? how to add number of student in the list
        //students.stream()
        //        .forEach(s -> System.out.println(s));
    }

    static void deleteStudent(ArrayList<Person> students) {

        int studentToDelete;

        //input block
        System.out.print("Enter number of student to delete: ");
        Scanner input = new Scanner(System.in);
        studentToDelete = input.nextInt();

        if ((studentToDelete < 0) || (studentToDelete > students.size() - 1)) {
            System.out.println("ERROR! Wrong student number!");
            return;
        }
        //input - OK
        students.remove(studentToDelete);
    }

    static void addStudent(ArrayList<Address> addresses, ArrayList<Person> people) {

        //input block
        Scanner input_add = new Scanner(System.in);

        System.out.println("PERSONAL DATA: ");
        System.out.print("Enter surname: ");
        String surname = input_add.nextLine();

        System.out.print("Enter name: ");
        String name = input_add.nextLine();

        System.out.print("Enter year of birth: ");
        //int yearBirth = Integer.valueOf(input.nextInt());
        String yearBirth = input_add.nextLine();

        System.out.print("Enter status - (T) for teacher, any other letter - for student: ");
        String opLetter = input_add.nextLine();
        String pStatus;
        if (Character.toLowerCase(opLetter.charAt(0)) == 't') {
            pStatus = "Teacher";
        } else {
            pStatus = "Student";
        }

        System.out.println("ADDRESS DATA: ");
        System.out.print("Enter city: ");
        String city = input_add.nextLine();

        System.out.print("Enter street: ");
        String street = input_add.nextLine();

        System.out.print("Enter building: ");
        String building = input_add.nextLine();

        System.out.print("Enter apartment: ");
        String apartment = input_add.nextLine();

        //adding block
        addresses.add(new Address(city, street, building, apartment));
        //!?!? not sure, that correct address will be added, but it is correct! How to obtain pointer to newly added address?
        people.add(new Person(surname, name, Integer.valueOf(yearBirth), addresses.get(addresses.size() - 1), pStatus));
    }
}
