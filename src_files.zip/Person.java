public class Person {
    private String name;
    private String surname;
    private int yearBirth;
    private Address address;
    private String pStatus; //student, teacher, etc.
    private boolean opFlag; //true, if something need to be done with current person

    //constructors
    public Person(String name, String surname, int yearBirth, Address address, String pStatus) {
        this.name = name;
        this.surname = surname;
        this.yearBirth = yearBirth;
        this.address = address;
        this.pStatus = pStatus;
    }

    public Person(String name, String surname, int yearBirth, Address address) {
        this.name = name;
        this.surname = surname;
        this.yearBirth = yearBirth;
        this.address = address;
        this.pStatus = "Student"; //create default
    }

    //setters and getters
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getSurname() {
        return this.surname;
    }

    public void setYear(int yearBirth) {
        this.yearBirth = yearBirth;
    }

    public int getYear() {
        return this.yearBirth;
    }

    public void setPstatus(String pstatus) {
        this.pStatus = pStatus;
    }

    public String getPstatus() {
        return pStatus;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Address getAddress() {
        return this.address;
    }

    @Override
    public String toString() {
        return this.getName() + ", " + this.getSurname() + ", " + this.getYear() + ", " + this.getPstatus() + ", address: " + this.address;
    }

}
