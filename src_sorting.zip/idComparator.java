import java.util.Comparator;

    //sort by ID
    public class idComparator implements Comparator<Person> {

        @Override
        public int compare(Person o1, Person o2) {
            return o1.getPersId() - o2.getPersId();
        }
    }