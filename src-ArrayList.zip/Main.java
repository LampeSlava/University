import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        ArrayList<Address> addresses = new ArrayList<>(10);
        addresses.add(new Address("New York", "5th Ave.", "1", "1B"));
        addresses.add(new Address("New York", "Broadway", "10", "100"));
        addresses.add(new Address("Washington D.C.", "Main st.", "5", "15"));
        addresses.add(new Address("New Vasyuki", "Whiskey st.", "1", "1"));
        addresses.add(new Address("Hogwarts", "Castle blvd.", "X", "XXX"));

        //Address addressStudent = new Address("Minsk", "Kalvarijskaya", "21A", "3B");
        //Address addressTeacher = new Address("Minsk", "Brovk", "1", "149");

        ArrayList<Person> students = new ArrayList<>(10);
        students.add(new Person("John", "Doe", 1970, addresses.get(0), "Student"));
        students.add(new Person("Donald", "Trump", 1940, addresses.get(1), "Student"));
        students.add(new Person("Blin", "Clinton", 1945, addresses.get(2), "Student"));
        students.add(new Person("Henry", "Ford", 1900, addresses.get(3), "Student"));
        students.add(new Person("Harry", "Potter", 1980, addresses.get(4), "Student"));

        //interface loop
        boolean exitProgram = false;
        String opLetter;
        char opChar;
        Scanner input = new Scanner(System.in);

        while (!exitProgram) {
            showMenu();
            listStudents(students);

            System.out.print("Enter operation code (letter in brackets): ");
            opLetter = input.nextLine(); opChar = Character.toLowerCase(opLetter.charAt(0));

            switch (opChar) {
                case 'e':
                    exitProgram = true;
                    break;
                case 'l':
                    break;
                case 'n':
                    System.out.println("New student! Not implemented yet!");
                    break;
                case 'u':
                    System.out.println("Update student! Not implemented yet!");
                    break;
                case 'd':
                    students = deleteStudent(students);
                    break;
                default:
                    System.out.println("Enter correct letter!");
            }

        }
        input.close();

        /*Person testguy = new Person("Vasya", "Pupkin", 1985, addressStudent, "Student");
        System.out.println("Info about student: " + testguy);

        Teacher teacher1 = new Teacher("Vova", "Putler", 1955, addressTeacher, "Teacher", 1, 10);
        System.out.println("Info about teacher: " + teacher1);

        System.out.println("Info about teacher's wage: " + teacher1.getTariff() * teacher1.getHours());

        teacher1.setTariff(12.5);

        System.out.println("Now hourly tariff is " + teacher1.getTariff());
        System.out.println("Now teacher's wage: " + teacher1.getTariff() * teacher1.getHours());

        StudyGroup newGroup = new StudyGroup("New group", 2, teacher1, testguy);
        System.out.println("Info about group: " + newGroup);

        addressStudent.setApartment("126");
        addressTeacher.setApartment("99");

        System.out.println("Info about persons after address change");
        System.out.println("Info about student: " + testguy);
        System.out.println("Info about teacher: " + teacher1);
*/

    }

     static void showMenu() {
        System.out.println("+------------------------------------------------------------------------------------------+");
        System.out.println("|  (L)ist students  |  (N)ew student  |  (U)pdate student  |  (D)elete student  |  (E)xit  |");
        System.out.println("+------------------------------------------------------------------------------------------+");
    }

     static void listStudents(ArrayList<Person> students) {
        for (int i = 0; i < students.size() - 1; i++) {
            System.out.println("Student " + i + ": " + students.get(i));
        }
        System.out.println("+------------------------------------------------------------------------------------------+");
    }

      static ArrayList<Person> deleteStudent (ArrayList<Person> students) {

        int studentToDelete;

        //input block
        System.out.print("Enter number of student to delete: ");
        Scanner input = new Scanner(System.in);
        studentToDelete = input.nextInt();

        if ((studentToDelete < 0) || (studentToDelete > students.size() - 1)) {
            System.out.println("ERROR! Wrong student number!");
            return students;
        }

        //input - OK
        ArrayList<Person> tempStudents = new ArrayList<>(students.size() - 1);

        int j = 0; //counter for new array

        for (int i = 0; i < students.size(); i++) {
            if (i != studentToDelete) {
                tempStudents.add(j, students.get(i));
                j++;
            }
        }
        return tempStudents;
    }
}
